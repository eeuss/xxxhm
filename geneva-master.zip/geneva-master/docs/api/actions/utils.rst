geneva.actions.utils 
====================

.. automodule:: utils
   :members:
   :undoc-members:
   :show-inheritance:
