geneva.actions.fragment
=======================

.. automodule:: fragment
   :members:
   :undoc-members:
   :show-inheritance:
