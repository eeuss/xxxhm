geneva.actions.strategy
=======================

.. automodule:: strategy
   :members:
   :undoc-members:
   :show-inheritance:
