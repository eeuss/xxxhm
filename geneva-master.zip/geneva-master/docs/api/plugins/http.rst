geneva.plugins.http
============================

.. automodule:: plugins.http.client
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: plugins.http.server
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: plugins.http.plugin
   :members:
   :undoc-members:
   :show-inheritance:
