geneva.plugins.plugin_client
============================

.. automodule:: plugin_client
   :members:
   :undoc-members:
   :show-inheritance:
