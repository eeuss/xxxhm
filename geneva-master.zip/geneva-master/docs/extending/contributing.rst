Contributing
=============

Contributions are welcome! You are encouraged to fork the repository, open Github issues with us, 
or just make a pull request. If you are interested in becoming more involved with the team or 
development, checkout our website a `https://censorship.ai <https://censorship.ai>`_ and drop us a line! 
